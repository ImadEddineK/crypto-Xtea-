

package Tp_Xtea;


import java.security.InvalidKeyException;


import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.util.Arrays;
import java.util.Scanner;


public class Xtea_algo {

    public static Scanner sc = new Scanner(System.in);
    
    public static void main(String[] args) throws IOException, InvalidKeyException {
        
        while(true) {
            
            System.out.println("Choisissez: ");
            System.out.println(" 1. Test de chiffrement/dechiffrement d'un fichier;");
            System.out.println(" 2. Chiffrement/Dechiffrement avec une cle sur 128 bits (16 octets) et la taille des blocs en claires sur 64 bits (8 octets);");
            System.out.println();

            System.out.print("Choix: ");
            int choix = sc.nextInt();

            byte[] texte_claire = "Hello world".getBytes();
            byte[] cl�, texte_chifr�, texte_d�chiffr�;
 
            if (choix == 1) {
                
                System.out.print("Entrez l'emplacement du fichier: ");
                String fichier = "C:\\Users\\f.txt";
                fichier = sc.next();

                texte_claire = Files.readAllBytes(FileSystems.getDefault().getPath(fichier));

                System.out.print("Cle [16 octets(128 bits)]: ");
                cl� = sc.next().getBytes();

                System.out.println("Texte claire: " + new String(texte_claire));
                
                Xtea_class x = new Xtea_class();
                x.engineInit(cl�, false);
                texte_chifr� = x.engineCrypt(texte_claire, 0);
                
                System.out.println("Texte chiffr�: " + new String(texte_chifr�));
                
                Xtea_class x1 = new Xtea_class();
                x1.engineInit(cl�, true);
                texte_claire = x1.engineCrypt(texte_chifr�, 0);
                
                System.out.println("Texte d�chiffr�: " + new String(texte_claire));
                
            } else if (choix == 2) {
            
                System.out.print("Cl� [16 octets(128 bits)]: ");
                cl� = sc.next().getBytes();
                
                System.out.print("Bloc [8 octets(64 bits)]: ");
                texte_claire = sc.next().getBytes();
                
                Xtea_class x = new Xtea_class();
                x.engineInit(cl�, false);
                texte_chifr� = x.engineCrypt(texte_claire, 0);
                
                System.out.println("Texte chiffr�: " + new String(texte_chifr�));
                
                Xtea_class x1 = new Xtea_class();
                x1.engineInit(cl�, true);
                texte_claire = x1.engineCrypt(texte_chifr�, 0);
                
                System.out.println("Texte d�chiffr�: " + new String(texte_claire));
                
            }
            
            System.out.println();
            System.out.println("-----------------------------------------------");
            System.out.println();
            
        }
        
    }
    
}

